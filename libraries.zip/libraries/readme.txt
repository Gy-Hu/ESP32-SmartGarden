安装库的详细信息，请参阅：http://www.arduino.cc/en/Guide/Libraries
